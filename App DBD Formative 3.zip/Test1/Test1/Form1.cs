﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Test1
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// here is where i placed the database link to the database when i opened it on the SQL server object Explorer, you can add this when you click on the server view and within the top row add the server that has purple rings on the side
        /// ...................................................by the database i added which database i want to access. 
        /// </summary>
        string connectionString = @"Data Source=ERIKRAGNARDESKT;database=CTUDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public Form1()
        {
            InitializeComponent();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// this button is an onclick event and selects Name and Surname from the databaseand allowing a get and set method in a seperate class Clients.cs
        /// </summary>
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
            SqlCommand cmd = new SqlCommand("select * from AucklandPark.StudentInformationTable");
            cmd.Connection = sqlConnection;
            SqlDataReader reader = cmd.ExecuteReader();
            List<Client> clients = new List<Client>();
            while (reader.Read())
            {
                Client client = new Client();
                client.Name = reader["Name"].ToString();
                client.Surname = reader["Surname"].ToString();
                clients.Add(client);
            }
            sqlConnection.Close();
            dataGridView1.DataSource = clients;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
