﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test1
{
    public class Client
    {
        /// <summary>
        /// this is a get and set method for the name and surname
        /// </summary>
        public string Name { get; set; }
        public string Surname { get; set; }
    }
}
